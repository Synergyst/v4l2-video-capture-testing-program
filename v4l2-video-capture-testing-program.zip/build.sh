#/bin/bash

make -j16